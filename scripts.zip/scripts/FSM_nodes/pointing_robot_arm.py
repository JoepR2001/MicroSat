#!/usr/bin/env python


def pointing_robot_arm():
	pass
