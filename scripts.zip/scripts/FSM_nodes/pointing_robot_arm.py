#!/usr/bin/env python

from arm_camera import DahengCamera
from detect_balloon import get_balloon_loc
import rospy
import gxipy as gx
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from detect_balloon import get_balloon_loc
import cv2
import time
from sensor_msgs.msg import JointState
from data_handler import DataHandler
from arm_func.DH import Transform

handler = DataHandler()
handler.subscribe_to_topic('/robot/arm/joint_states', JointState)


hue_lower = 18 #cv2.getTrackbarPos("Hue Lower", "Color Range Adjustments")
saturation_lower = 114 #cv2.getTrackbarPos("Saturation Lower", "Color Range Adjustments")
value_lower = 0 #cv2.getTrackbarPos("Value Lower", "Color Range Adjustments")
hue_upper = 79 #cv2.getTrackbarPos("Hue Upper", "Color Range Adjustments")
saturation_upper = 255 #cv2.getTrackbarPos("Saturation Upper", "Color Range Adjustments")
value_upper = 255 #cv2.getTrackbarPos("Value Upper", "Color Range Adjustments")
minDist = 10000 #cv2.getTrackbarPos("minDist", "Color Range Adjustments")
Param1 = 227 # cv2.getTrackbarPos("Param1", "Color Range Adjustments")
Param2 = 18 # cv2.getTrackbarPos("Param2", "Color Range Adjustments")


detection_settings = {
	"hue_lower": hue_lower,
	"saturation_lower": saturation_lower,
	"value_lower": value_lower,
	"hue_upper": hue_upper,
	"saturation_upper": saturation_upper,
	"value_upper": value_upper,
	"minDist": minDist,
	"param1": Param1,
	"param2": Param2,
	"minRadius": 5,
	"maxRadius": 1000
}


def pointing_robot_arm():
	camera = DahengCamera()
	
	while True:
		image = camera.capture_image()
		circle = get_balloon_loc(image, detection_settings)
		
		x, y, radius = circle
		if x == 0 or y ==0:
			#print("no ballz")
			pass
		else:
			img_width = len(image[0])
			img_height = len(image)		
			x_center = img_width / 2
			y_center = img_height / 2
			
			delta_x = x - x_center
			delta_y = y - y_center
			
			q = np.array(handler.joint_state[-1]) - [0,-np.pi/2*1,0,-np.pi/2,0,np.pi/4]
			arm = Transform(0) 
			print(arm.fk_calc(q))
		
		key = cv2.waitKey(1) & 0xFF
		if key == ord('q'):
			break

	camera.close_camera()

	return "FINISH"
