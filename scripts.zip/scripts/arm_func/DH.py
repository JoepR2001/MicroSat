#!/usr/bin/env python
"""
Created on Thu Jan 11 10:45:54 2024

@author: arnou
"""
import numpy as np
import matplotlib.pyplot as plt

pi = np.pi


class Transform():
	def __init__(self, T_Goal):
		self.T_Goal = T_Goal
		self.link1 = 180.7
		self.link2 = 478.4
		self.link3 = 360
		self.link4 = 119.85
		self.link5 = 174.15
		self.pi2 = np.pi/2
		self.offset = 200
		self.DH = np.array([
							[0, self.link1, 0, -self.pi2],
							[-self.pi2, self.link5, self.link2,0],
							[0, -self.link5, self.link3, 0],
							[self.pi2, self.link5, 0, self.pi2],
							[0, self.link4, 0, -self.pi2],
							[0, self.offset, 0, 0]
				       		])
				       
		self.theta = self.DH[:,0]
		self.d = self.DH[:,1]
		self.a = self.DH[:,2]
		self.alpha = self.DH[:,3]
		
		
	def transform_matrix(self, alpha, a, d, theta):

		# Take the DH-Parameters as inputs (one row of the DH-Table)
		# Output the homogenous transformation matrix T for any input joint position theta.

		# Row 1 of the matrix

		r_1_1 = np.cos(theta)
		r_1_2 = -1*np.sin(theta)*np.cos(alpha)
		r_1_3 = np.sin(theta)*np.sin(alpha)
		r_1_4 = np.cos(theta)*a

		# Row 2 of the matrix
		r_2_1 = np.sin(theta)
		r_2_2 = np.cos(theta)*np.cos(alpha)
		r_2_3 = -1*np.cos(theta)*np.sin(alpha)
		r_2_4 = np.sin(theta)*a

		# Row 3 of the matrix
		r_3_1 = 0
		r_3_2 = np.sin(alpha)
		r_3_3 = np.cos(alpha)
		r_3_4 = d

		# Row 4 of the matrix
		r_4_1 = 0
		r_4_2 = 0
		r_4_3 = 0
		r_4_4 = 1

		# Build the complete transformation matrix in an np.array
		T = np.array([[r_1_1, r_1_2, r_1_3, r_1_4],
				 [r_2_1, r_2_2, r_2_3, r_2_4],
				 [r_3_1, r_3_2, r_3_3, r_3_4],
				 [r_4_1, r_4_2, r_4_3, r_4_4]])

		return T
    
	def fk_calc(self, q: np.ndarray):
		# Initialize a list of the transforms we will need
		
		T_0_0 = np.array([[1, 0, 0, 0],  # create T_0_0
						  [0, 1, 0, 0],
						  [0, 0, 1, 0],
						  [0, 0, 0, 1]])

		T_all = [T_0_0]  
		for i in range(len(self.alpha)):
			T = self.transform_matrix(self.alpha[i], self.a[i], self.d[i], self.theta[i] + q[i])                # Get each transformation matrix
			T_0_i = np.dot(T_all[i],T)  
			
			T_all.append(T_0_i) 
			
		return T_all
    

    
	def endpointT(self,q):
		T_end = self.fk_calc(q)[-1]

		e_pos = np.linalg.norm(T_end[:,3] - self.T_Goal[:,3])
		e_rot = np.linalg.norm(T_end[:,0:3] - self.T_Goal[:,0:3]) *1000

		return  e_rot + e_pos
    
	def error(self,T): 
		e_pos = self.T_Goal[0:3,3]-T[0:3,3] 
		R_goal = self.T_Goal[0:3,0:3]
		R_final = T[0:3,0:3]
		e_rot = np.dot(R_goal, R_final.T)
		e_rot_v = self.matrixtovector(e_rot)

		e = np.concatenate((e_pos,e_rot_v))

		return e
        
	def jacobian(self,T_all):
		J = np.zeros((6,len(T_all)-1))
		z = np.zeros((3,len(T_all)))
		t = np.zeros((3,len(T_all)))

		for n in range(len(T_all)):            
			z[:,n] = T_all[n][0:3,2]    
			t[:,n] = T_all[n][0:3,3]

		for i in range(len(T_all)-1):
			J[0:3, i] = np.round(np.cross(z[:,i], (t[:,-1]-t[:,i])),3)   # linear components
			J[3:6, i] =  np.round(z[:,i],3)

		return J
		
	def matrixtovector(self,R):
		theta = np.arccos((np.trace(R)-1)/2)
		w = np.array([R[2,1] - R[1,2],
				      R[0,2] - R[2,0],
				      R[1,0] - R[0,1]])
		u = 1 / (2*np.sin(theta)) * w
		v = theta * (u / np.linalg.norm(u))
				
		return v
		 
	def finddq(self,q=[0,0,0,0,0,0]):
		T_all = self.fk_calc(q)
		e = self.error(T_all[-1])
		J = self.jacobian(T_all)

		Lambda = 0.1
		I = np.eye(6)
		Jp = J.T.dot(np.linalg.inv(J.dot(J.T)+Lambda*I))
		K = 0.5
		dq = np.dot(Jp,(K*e))

		return dq , e 
		
	def findq(self,q=[0,0,0,0,0,0]):
		e = 1000
		n = 0
		while e > 0.00001 and n < 10000:
			dq, e_v = self.finddq(q)
			q = q + dq*0.1
			e = np.linalg.norm(e_v)
			n += 1
		print('n', n, e)
		q = self.normalize(q)
		
		q_actual = q + [0,-self.pi2*1,0,-self.pi2,0,self.pi2/2]

		for i in range(len(q_actual)):
			if q_actual[i]>= pi:
				q_actual[i] -=2*pi 
			elif q_actual[i]<= -pi:
				q_actual[i] += 2* pi
		return q_actual
        
	def normalize(self,q):
		for n in range(len(q)):
			while q[n] >= np.pi:
				q[n] -= 2*np.pi 
			while q[n] <= -np.pi:
				q[n] += 2*np.pi        
		return q

if __name__ == "__main__":
    ee = []
    ddq = []
    link1 = 180.7
    link2 = 478.4
    link3 = 360
    link4 = 119.85
    link5 = 174.15
    pi2 = np.pi/2
    offset = 200
    pi = np.pi
    DH = np.array([[0,link1,0,-pi/2],
                   [-2*pi2,link5,link2,0],
                   [0, -link5, link3, 0],
                   [0, link5,0,pi2],
                   [0,link4,0,-pi2],
                   [pi2/2,offset, 0,0]])
    
    
    T_Goal = np.array([[1,0,0,link3+link4],
                      [0, 1, 0, link5 + offset],
                      [0, 0, 1, link1+link2],
                      [0, 0,0,1]])
    
    test = transform(DH, T_Goal)
    
    
    T_Goal2 = test.fk_calc([0,0,0,0,0,pi2])[-1]
    test.T_Goal = T_Goal2
    
    q = [0,0,0,0,0,0]
    
    q_test = test.findq(q)
    print(q_test)
    #q_bounds = [(-pi,pi),(-pi,pi),(-pi,pi),(-pi,pi),(-pi,pi),(-pi,pi)]
    #res = minimize(test.endpointT, q, bounds = q_bounds, method='Nelder-Mead')
    #print(res)
    #print(test.fk_calc(res.x)[-1])
    #result = test.fk_calc(res.x)
    
    
    # Create a figure and a 3D axis
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    
    axis1 = np.array([[1, 0, 0, 0],
                      [0, 1, 0, 0],
                      [0, 0, 1, 0],
                      [0, 0, 0, 1]])
    result = test.fk_calc(q_test)
    
    axis2 =   T_Goal2 @ axis1
    
    
    #axis3 = result[-1] @ axis1
    # Define the origin point
    axes = [axis2, axis1]
    
    for T in result:
        
       axes.append(T)
    
    # Plot the axes as lines from the origin to the endpoints
    for axis in axes:
        ax.plot([axis[0,3], axis[0,3]+axis[0,0]*100], [axis[1,3], axis[1,3]+axis[1,0]*100],[axis[2,3], axis[2,3]+axis[2,0]*100], label='X-axis', color='r')
        ax.plot([axis[0,3], axis[0,3]+axis[0,1]*100], [axis[1,3], axis[1,3]+axis[1,1]*100],[axis[2,3], axis[2,3]+axis[2,1]*100], label='Y-axis', color='g')
        ax.plot([axis[0,3], axis[0,3]+axis[0,2]*100], [axis[1,3], axis[1,3]+axis[1,2]*100],[axis[2,3], axis[2,3]+axis[2,2]*100], label='Z-axis', color='b')
    
    for n in range(2,len(axes)):
        ax.plot([axes[n-1][0,3],axes[n][0,3]],[axes[n-1][1,3],axes[n][1,3]],[axes[n-1][2,3],axes[n][2,3]])
    # Set axis labels
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    R_goal = T_Goal2[0:3,0:3]
    R_final = axes[-1][0:3,0:3]
    
    # Add a legend
    #ax.legend()
    
    # Show the 3D plot
    plt.show()
    fig, ax = plt.subplots(1,2)
    ax[0].plot(ee)
    ax[1].plot(ddq)
