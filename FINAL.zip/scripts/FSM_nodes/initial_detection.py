#!/usr/bin/env python


import rospy
import cv2
import numpy as np
import time

from base_func.base_pos_controller import publish_move_goal
from arm_func.joint_controller import send_follow_joint_trajectory_action_goal
from detect_balloon import get_balloon_loc
from cv_bridge import CvBridge
from arm_func.DH import Transform


"""
This file is the initial detection node

It consists of the following functionalities:
- Target detection algorithm - TODO
- Rotate vehicle delta theta - PROGRESS
"""


hue_lower = 18 # cv2.getTrackbarPos("Hue Lower", "Color Range Adjustments")
saturation_lower = 75 # cv2.getTrackbarPos("Saturation Lower", "Color Range Adjustments")
value_lower = 0 # cv2.getTrackbarPos("Value Lower", "Color Range Adjustments")
hue_upper = 75 # cv2.getTrackbarPos("Hue Upper", "Color Range Adjustments")
saturation_upper = 255 # cv2.getTrackbarPos("Saturation Upper", "Color Range Adjustments")
value_upper = 255 # cv2.getTrackbarPos("Value Upper", "Color Range Adjustments")
minDist = 10000 # cv2.getTrackbarPos("minDist", "Color Range Adjustments")
Param1 = 227 # cv2.getTrackbarPos("Param1", "Color Range Adjustments")
Param2 = 18 # cv2.getTrackbarPos("Param2", "Color Range Adjustments")

detection_settings = {
	"hue_lower": hue_lower,
	"saturation_lower": saturation_lower,
	"value_lower": value_lower,
	"hue_upper": hue_upper,
	"saturation_upper": saturation_upper,
	"value_upper": value_upper,
	"minDist": minDist,
	"param1": Param1,
	"param2": Param2,
	"minRadius": 5,
	"maxRadius": 100
}


def move_arm(context):
	context["arm"].T_goal = context["T_goal"]	
	context["q_actual"] = context["arm"].findq()
	input_arm = {
		"q": context["q_actual"],
		"v": [],
		"a": [],
		"e": [],
		"t": 4
	}
	send_follow_joint_trajectory_action_goal(input_arm)
	
	rospy.sleep(2)
	
	while context["handler"].arm_status_text != 3:
		rospy.loginfo(f"ARM moving")
		print(context["handler"].arm_status_text)
		rospy.sleep(1)
	return context


def rotate_base(context, theta):
	input_base = {    

		"goal" : 	[0.0, 0.0, theta],
		"max_lin" : 	[0.0, 0.0, 0.0],
		"max_ang" :	[0.0, 0.0, 0.1]
	}
	publish_move_goal(input_base)
	rospy.sleep(1)
	
	while context["handler"].base_status_text != "Goal has been reached":
		rospy.loginfo(f"ERROR, Current status: {context['handler'].base_status_text}")
		rospy.loginfo("BASE moving")
		rospy.sleep(1)


def initial_detection(context):
	# 1. initial arm position
	T_Goal = np.array([
		[0,0,-1,-450],
		[0,1,0,0],
		[1,0,0,450],
		[0,0,0,1]
	])

	context["T_goal"] = T_Goal
	context["arm"] = Transform(T_Goal)
	
	context = move_arm(context)

	# 2. ball detection + base rotation
	bridge = CvBridge()
	image = bridge.imgmsg_to_cv2(context["handler"].camera_matrix, "bgr8")
	img_width = len(image[0])
	img_height = len(image)	
	x_center = img_width / 2
	y_center = img_height / 2
	
	i = 0
	lst_radius = []
	lst_x = []
	
	start_time = time.time()
	
	while True:
		try:
			image = bridge.imgmsg_to_cv2(context["handler"].camera_matrix, "bgr8")
		except Exception as e:
			rospy.logerr("CvBridge Error: {0}, transition to FINSIH".format(e))
			return "FINISH", context
			
		circle = get_balloon_loc(image, detection_settings)
		x, y, radius = circle
			
		if x == 0 or y ==0:
			rospy.sleep(0.1)
			if time.time() - start_time > 2.5:
				rospy.logerr("No ball detected, CHOARSE TURN")
				rotate_base(context, -0.25)
		else:
			#reset timer
			start_time = time.time()
			i += 1
			
			lst_x.append(x)
			lst_radius.append(radius)
			
			if i == 5:	
				# 70 radius
				# 3.9 m
				delta_x = np.mean(lst_x) - x_center
				
				context['dist_target'] = 27300 / np.mean(lst_radius) # 27.3
				print(f"distance to target mm: {context['dist_target']}")
				
				print(f"delta x: {delta_x}")
				
				
				if abs(delta_x) < 20:
					context['dist_target'] = 27300 / np.mean(lst_radius) # 27.3
				
					print("Target aligned, transition to APPROACH TARGET")
					return "APPROACH TARGET", context
				
				print(f"input rotate theta: {delta_x / 50 * 0.02}")
				
				if delta_x < 0:
					rotate_base(context, max(delta_x / 50 * 0.02, 0.02))
				else:
					rotate_base(context, -max(delta_x / 50 * 0.02, 0.02))
				
				i = 0
				lst_radius = []
				lst_x = []
		
		
		key = cv2.waitKey(1) & 0xFF
		if key == ord('q'):
			break
			
	
if __name__ == "__main__":
	pass
