#!/usr/bin/env python


import rospy
import numpy as np
import cv2

from detect_balloon import get_balloon_loc
from arm_func.joint_controller import send_follow_joint_trajectory_action_goal



def move_arm(context):
	context["arm"].T_goal = context["T_goal"]
				
	q_actual = context["arm"].findq()
	input_arm = {
		"q": q_actual,
		"v": [],
		"a": [],
		"e": [],
		"t": 3
	}
	send_follow_joint_trajectory_action_goal(input_arm)
	
	rospy.sleep(2)
	
	while context["handler"].arm_status_text != 3:
		rospy.loginfo(f"ARM moving")
		rospy.sleep(1)
		
	return context


def approach_robot_arm(context):
	dist_target = context['dist_target']
	print(f"CURRENT DISTANCE FROM TARGET: {dist_target}")
	
	if dist_target < 100:
		print("HOLY SHIET, WE DID IT")
		return "FINISH", context
		
	elif dist_target > 350:
		dist_target = (context['dist_target'] - 300) * 2
		return "APPROACH TARGET", context 
	else:
		context["T_goal"][0][-1] += - dist_target
		context = move_arm(context)
		
		return "FINISH", context
