#!/usr/bin/env python


import rospy
import numpy as np
import cv2
import time

from detect_balloon import get_balloon_loc
from arm_func.joint_controller import send_follow_joint_trajectory_action_goal


hue_lower = 18 #cv2.getTrackbarPos("Hue Lower", "Color Range Adjustments")
saturation_lower = 75 #cv2.getTrackbarPos("Saturation Lower", "Color Range Adjustments")
value_lower = 0 #cv2.getTrackbarPos("Value Lower", "Color Range Adjustments")
hue_upper = 75 #cv2.getTrackbarPos("Hue Upper", "Color Range Adjustments")
saturation_upper = 255 #cv2.getTrackbarPos("Saturation Upper", "Color Range Adjustments")
value_upper = 255 #cv2.getTrackbarPos("Value Upper", "Color Range Adjustments")
minDist = 200000000000000 #cv2.getTrackbarPos("minDist", "Color Range Adjustments")
Param1 = 100 # cv2.getTrackbarPos("Param1", "Color Range Adjustments")
Param2 = 18 # cv2.getTrackbarPos("Param2", "Color Range Adjustments")


detection_settings = {
	"hue_lower": hue_lower,
	"saturation_lower": saturation_lower,
	"value_lower": value_lower,
	"hue_upper": hue_upper,
	"saturation_upper": saturation_upper,
	"value_upper": value_upper,
	"minDist": minDist,
	"param1": Param1,
	"param2": Param2,
	"minRadius": 5,
	"maxRadius": 10000
}


def move_arm(context):

	context["arm"].T_goal = context["T_goal"]
				
	context["q_actual"] = context["arm"].findq(context["q_actual"])
	input_arm = {
		"q": context["q_actual"],
		"v": [],
		"a": [],
		"e": [],
		"t": 3
	}
	send_follow_joint_trajectory_action_goal(input_arm)
	
	rospy.sleep(2)
	
	while context["handler"].arm_status_text != 3:
		rospy.loginfo(f"ARM moving")
		rospy.sleep(1)
		
	return context


def calculate_delta_T_goal(context, delta_x, delta_y, radius):
	x, y = context["T_goal"][1][-1], context["T_goal"][2][-1]
	
	# 0.331717 = x-FoV in radians
	# 0.248787 = y-FoV in radians
	# 71500 = radius to distance factor
	
	delta_x_T_goal = np.tan((delta_x / context["dc_x_center"]) * 0.331717) * (71500 / radius)
	delta_y_T_goal = np.tan((delta_y / context["dc_y_center"]) * 0.248787) * (71500 / radius)
	
	if abs(delta_x_T_goal) > 500 or abs(delta_y_T_goal) > 500:
		rospy.logerr(f"Target goal out of reach, delta x target: {delta_x_T_goal}, delta y target: {delta_y_T_goal}")
		return "FINISH", context
	
	context['dist_target'] = 71500 / radius
	context["T_goal"][1][-1] = x + delta_x_T_goal
	context["T_goal"][2][-1] = y + delta_y_T_goal
	
	print(f"delta_x: {delta_x}, delta_y: {delta_y}, radius: {radius}, distance:{context['dist_target']}")
	print(f"delta_x_T_GOAL: {delta_x_T_goal}")
	print(f"T goal: {context['T_goal']}")
	
	return context


def pointing_robot_arm(context):
	i = 0
	
	lst_radius = []
	lst_x = []
	lst_y = []
	
	start_time = time.time()
	
	while True:
		image = context['daheng_camera'].capture_image()
		circle = get_balloon_loc(image, detection_settings)
		x, y, radius = circle
		
		print("x,y,radius", x,y,radius)
			
		
		if x == 0 and y == 0:
			rospy.sleep(0.1)
			if time.time() - start_time > 5:
				rospy.logerr("No ball detected, transition to APPROACH TARGET")
				return "APPROACH TARGET", context		
		else:
			#reset timer
			start_time = time.time()
			
			i += 1

			if i > 3:
				lst_x.append(x)
				lst_y.append(y)
				lst_radius.append(radius)

			image = context['daheng_camera'].capture_image()
			circle = get_balloon_loc(image, detection_settings)
			
			if i == 8:					
				print("NEXT MOVE")
	
				delta_x = np.mean(lst_x) - context["dc_x_center"]
				delta_y = context["dc_y_center"] - np.mean(lst_y)
				
				if abs(delta_x) < 10000 / context['dist_target'] and abs(delta_y) < 10000 / context['dist_target']:
					print("Target goal alligned, transition to APPROACH ROBOT ARM")
					return "APPROACH ROBOT ARM", context
			
				context = calculate_delta_T_goal(context, delta_x, delta_y, np.mean(lst_radius))
				context = move_arm(context)
				
				i = 0
				lst_radius = []
				lst_x = []
				lst_y = []


		key = cv2.waitKey(1) & 0xFF
		if key == ord('q'):
			break

	camera.close_camera()

	return "FINISH", context

