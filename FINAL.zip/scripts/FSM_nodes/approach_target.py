#!/usr/bin/env python


from base_func.base_pos_controller import publish_move_goal
import rospy
import time

"""
This file is the approach target node

It consists of the following functionalities:
- Estimate target position (X, Y)
- Move rover towards target positions
"""


def move_rover(x, y, context, v=0.1):
	input_base = {
		"goal" : 	[x, y, 0.0],
		"max_lin" : 	[v, v, 0.0],
		"max_ang" :	[0.0, 0.0, 0.2]
	}
	
	publish_move_goal(input_base)
	rospy.sleep(1)
	
	while context["handler"].base_status_text != "Goal has been reached":
		rospy.loginfo("Approaching target")
		rospy.sleep(1)
	
	
def approach_target(context):
	move_rover((0.5 * context['dist_target']) / 1000, 0, context)
	
	print("50% distance to target, transition to POINTING ROBOT ARM")
	return "POINTING ROBOT ARM", context


if __name__ == "__main__":
	pass
