robot@sxlsk-230307aa:~$ rosrun microsat main.py
n 483 0.002483097564367914
[INFO] [1706867233.250263]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867235.253331]: ARM moving
1
[INFO] [1706867236.255219]: ARM moving
1
[INFO] [1706867237.256672]: ARM moving
1
[INFO] [1706867238.258287]: ARM moving
1
[INFO] [1706867239.260240]: ARM moving
1
distance to target mm: 2037.3134328358208
[INFO] [1706867241.001525]: Published MoveActionGoal
distance to target mm: 1978.2608695652173
[INFO] [1706867242.611820]: Published MoveActionGoal
distance to target mm: 2100.0
[INFO] [1706867244.221988]: Published MoveActionGoal
distance to target mm: 2007.3529411764707
[INFO] [1706867245.957427]: Published MoveActionGoal
distance to target mm: 2068.1818181818185
[INFO] [1706867247.572263]: Published MoveActionGoal
distance to target mm: 2275.0
[INFO] [1706867249.186141]: Published MoveActionGoal
distance to target mm: 2100.0
[INFO] [1706867250.794787]: Published MoveActionGoal
distance to target mm: 2275.0
[INFO] [1706867253.007071]: Published MoveActionGoal
distance to target mm: 2132.8125
[INFO] [1706867255.468796]: Published MoveActionGoal
distance to target mm: 2132.8125
[INFO] [1706867257.210391]: Published MoveActionGoal
distance to target mm: 2237.704918032787
[INFO] [1706867259.200081]: Published MoveActionGoal
distance to target mm: 2275.0
[INFO] [1706867260.933915]: Published MoveActionGoal
distance to target mm: 1950.0
[INFO] [1706867262.666162]: Published MoveActionGoal
distance to target mm: 2237.704918032787
[INFO] [1706867264.879550]: Published MoveActionGoal
distance to target mm: 2201.6129032258063
[INFO] [1706867267.100298]: Published MoveActionGoal
distance to target mm: 2275.0
[INFO] [1706867271.867542]: Published MoveActionGoal
distance to target mm: 2625.0
[INFO] [1706867275.657056]: Published MoveActionGoal
distance to target mm: 2237.704918032787
[INFO] [1706867277.756804]: Published MoveActionGoal
distance to target mm: 2166.6666666666665
[INFO] [1706867279.853285]: Published MoveActionGoal
distance to target mm: 2527.777777777778
[INFO] [1706867282.313567]: Published MoveActionGoal
distance to target mm: 2275.0
[INFO] [1706867284.792859]: Published MoveActionGoal
distance to target mm: 3412.5
[INFO] [1706867287.007925]: Published MoveActionGoal
distance to target mm: 2275.0
[INFO] [1706867289.595447]: Published MoveActionGoal
distance to target mm: 2237.704918032787
[INFO] [1706867292.921188]: Published MoveActionGoal
distance to target mm: 2353.448275862069
[INFO] [1706867296.028385]: Published MoveActionGoal
distance to target mm: 2437.5
[INFO] [1706867299.113451]: Published MoveActionGoal
distance to target mm: 2275.0
Target aligned, transition to APPROACH TARGET
[INFO] [1706867300.732162]: Published MoveActionGoal
[INFO] [1706867301.734145]: Approaching target
[INFO] [1706867302.735941]: Approaching target
[INFO] [1706867303.737637]: Approaching target
[INFO] [1706867304.745148]: Approaching target
[INFO] [1706867305.747829]: Approaching target
[INFO] [1706867306.749418]: Approaching target
[INFO] [1706867307.751518]: Approaching target
[INFO] [1706867308.752990]: Approaching target
[INFO] [1706867309.761938]: Approaching target
[INFO] [1706867310.763856]: Approaching target
[INFO] [1706867311.765597]: Approaching target
[INFO] [1706867312.767946]: Approaching target
[INFO] [1706867313.769578]: Approaching target
[INFO] [1706867314.777487]: Approaching target
[INFO] [1706867315.779739]: Approaching target
[INFO] [1706867316.782051]: Approaching target
[INFO] [1706867317.783780]: Approaching target
[INFO] [1706867318.785991]: Approaching target
[INFO] [1706867319.788285]: Approaching target
[INFO] [1706867320.790754]: Approaching target
[INFO] [1706867321.799173]: Approaching target
[INFO] [1706867322.800790]: Approaching target
[INFO] [1706867323.803000]: Approaching target
[INFO] [1706867324.804765]: Approaching target
50% distance to target, transition to POINTING ROBOT ARM
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 640 312 77
x,y,radius 644 310 75
x,y,radius 648 310 73
x,y,radius 646 310 76
x,y,radius 646 310 75
x,y,radius 646 310 75
x,y,radius 648 310 73
x,y,radius 644 312 76
x,y,radius 644 312 76
x,y,radius 642 308 74
x,y,radius 642 312 76
x,y,radius 640 312 76
x,y,radius 640 310 75
x,y,radius 640 308 74
x,y,radius 640 312 76
x,y,radius 644 310 73
x,y,radius 642 310 75
x,y,radius 642 310 75
x,y,radius 644 310 76
x,y,radius 644 310 76
NEXT MOVE
delta_x: -76.70000000000005, delta_y: 229.60000000000002, radius: 75.1, distance:952.063914780293
delta_x_T_GOAL: -33.65716432862797
T goal: [[   0    0   -1 -450]
 [   0    1    0  -33]
 [   1    0    0  551]
 [   0    0    0    1]]
n 422 0.002499201157567908
[INFO] [1706867331.705267]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867333.708016]: ARM moving
[INFO] [1706867334.709547]: ARM moving
[INFO] [1706867335.711520]: ARM moving
[INFO] [1706867336.714504]: ARM moving
[INFO] [1706867337.716495]: ARM moving
x,y,radius 648 310 74
x,y,radius 646 310 76
x,y,radius 646 310 76
x,y,radius 714 524 75
x,y,radius 716 522 72
x,y,radius 714 522 73
x,y,radius 716 524 72
x,y,radius 716 524 72
x,y,radius 714 524 76
x,y,radius 712 524 75
x,y,radius 712 526 76
x,y,radius 712 524 75
x,y,radius 710 524 75
x,y,radius 710 526 78
x,y,radius 710 526 76
x,y,radius 712 524 75
x,y,radius 718 522 71
x,y,radius 712 524 75
x,y,radius 714 524 75
x,y,radius 714 526 76
NEXT MOVE
delta_x: -16.700000000000045, delta_y: 48.0, radius: 74.65, distance:957.803081044876
delta_x_T_GOAL: -7.369474209576313
T goal: [[   0    0   -1 -450]
 [   0    1    0  -40]
 [   1    0    0  572]
 [   0    0    0    1]]
n 361 0.0024377145008276156
[INFO] [1706867343.361839]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867345.364671]: ARM moving
[INFO] [1706867346.366611]: ARM moving
[INFO] [1706867347.368664]: ARM moving
[INFO] [1706867348.370813]: ARM moving
[INFO] [1706867349.372967]: ARM moving
x,y,radius 714 524 75
x,y,radius 716 524 75
x,y,radius 714 524 76
x,y,radius 728 568 76
x,y,radius 732 568 72
x,y,radius 728 568 76
x,y,radius 730 568 74
x,y,radius 728 570 77
x,y,radius 732 568 72
x,y,radius 726 568 75
x,y,radius 726 570 76
x,y,radius 726 570 76
x,y,radius 728 568 74
x,y,radius 726 568 75
x,y,radius 726 572 78
x,y,radius 726 568 76
x,y,radius 728 568 75
x,y,radius 728 568 76
x,y,radius 730 568 74
x,y,radius 728 568 76
NEXT MOVE
Target goal alligned, transition to APPROACH ROBOT ARM
CURRENT DISTANCE FROM TARGET: 957.803081044876
[INFO] [1706867354.253052]: Published MoveActionGoal
[INFO] [1706867355.255264]: Approaching target
[INFO] [1706867356.256939]: Approaching target
[INFO] [1706867357.259124]: Approaching target
[INFO] [1706867358.260932]: Approaching target
[INFO] [1706867359.263284]: Approaching target
[INFO] [1706867360.264703]: Approaching target
[INFO] [1706867361.266174]: Approaching target
[INFO] [1706867362.268662]: Approaching target
[INFO] [1706867363.270736]: Approaching target
[INFO] [1706867364.272821]: Approaching target
50% distance to target, transition to POINTING ROBOT ARM
x,y,radius 730 568 74
x,y,radius 734 566 71
x,y,radius 730 568 74
x,y,radius 726 666 130
x,y,radius 726 664 129
x,y,radius 726 666 130
x,y,radius 726 666 129
x,y,radius 726 668 131
x,y,radius 726 668 130
x,y,radius 728 668 131
x,y,radius 732 666 130
x,y,radius 734 664 128
x,y,radius 734 668 132
x,y,radius 738 668 131
x,y,radius 740 668 131
x,y,radius 740 668 131
x,y,radius 740 666 129
x,y,radius 738 668 131
x,y,radius 738 666 129
x,y,radius 734 668 131
NEXT MOVE
delta_x: 12.299999999999955, delta_y: -111.89999999999998, radius: 121.6, distance:587.9934210526316
delta_x_T_GOAL: 3.332095651133169
T goal: [[   0    0   -1 -450]
 [   0    1    0  -36]
 [   1    0    0  541]
 [   0    0    0    1]]
n 374 0.0024744234147572497
[INFO] [1706867370.521641]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867372.524706]: ARM moving
[INFO] [1706867373.527060]: ARM moving
[INFO] [1706867374.528857]: ARM moving
[INFO] [1706867375.530712]: ARM moving
[INFO] [1706867376.532694]: ARM moving
x,y,radius 730 666 130
x,y,radius 728 666 130
x,y,radius 726 662 126
x,y,radius 710 548 127
x,y,radius 708 550 127
x,y,radius 704 548 127
x,y,radius 704 546 125
x,y,radius 704 546 126
x,y,radius 706 550 127
x,y,radius 710 550 128
x,y,radius 714 546 126
x,y,radius 716 548 127
x,y,radius 718 544 123
x,y,radius 716 548 126
x,y,radius 714 548 127
x,y,radius 710 546 126
x,y,radius 708 548 127
x,y,radius 704 550 129
x,y,radius 702 550 129
x,y,radius 702 550 128
NEXT MOVE
delta_x: -8.299999999999955, delta_y: -25.5, radius: 127.05, distance:562.7705627705628
delta_x_T_GOAL: -2.1520225324974955
T goal: [[   0    0   -1 -450]
 [   0    1    0  -38]
 [   1    0    0  534]
 [   0    0    0    1]]
n 317 0.002441809864805022
[INFO] [1706867382.934909]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867384.937587]: ARM moving
[INFO] [1706867385.940002]: ARM moving
[INFO] [1706867386.942232]: ARM moving
[INFO] [1706867387.944670]: ARM moving
[INFO] [1706867388.947014]: ARM moving
x,y,radius 706 548 127
x,y,radius 708 550 128
x,y,radius 714 548 125
x,y,radius 716 522 128
x,y,radius 722 520 124
x,y,radius 720 524 129
x,y,radius 720 524 129
x,y,radius 722 520 126
x,y,radius 720 524 129
x,y,radius 720 522 127
x,y,radius 720 522 129
x,y,radius 720 522 127
x,y,radius 718 524 129
x,y,radius 720 530 128
x,y,radius 724 522 125
x,y,radius 720 524 128
x,y,radius 720 522 128
x,y,radius 722 520 125
x,y,radius 720 522 127
x,y,radius 718 522 127
NEXT MOVE
Target goal alligned, transition to APPROACH ROBOT ARM
CURRENT DISTANCE FROM TARGET: 562.7705627705628
[INFO] [1706867394.863099]: Published MoveActionGoal
[INFO] [1706867395.864733]: Approaching target
[INFO] [1706867396.866557]: Approaching target
[INFO] [1706867397.868667]: Approaching target
[INFO] [1706867398.870852]: Approaching target
[INFO] [1706867399.872732]: Approaching target
[INFO] [1706867400.874886]: Approaching target
50% distance to target, transition to POINTING ROBOT ARM
x,y,radius 716 522 128
x,y,radius 716 522 126
x,y,radius 718 520 123
x,y,radius 714 594 204
x,y,radius 716 600 209
x,y,radius 722 596 204
x,y,radius 724 596 205
x,y,radius 718 598 208
x,y,radius 714 596 204
x,y,radius 708 596 204
x,y,radius 706 594 202
x,y,radius 708 592 201
x,y,radius 714 592 202
x,y,radius 720 596 204
x,y,radius 720 600 208
x,y,radius 722 598 206
x,y,radius 716 598 206
x,y,radius 710 596 204
x,y,radius 706 596 203
x,y,radius 704 598 205
NEXT MOVE
delta_x: -5.399999999999977, delta_y: -45.0, radius: 192.8, distance:370.850622406639
delta_x_T_GOAL: -0.9226328229031368
T goal: [[   0    0   -1 -450]
 [   0    1    0  -38]
 [   1    0    0  526]
 [   0    0    0    1]]
n 320 0.002486850546430254
[INFO] [1706867408.476913]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867410.479491]: ARM moving
[INFO] [1706867411.480780]: ARM moving
[INFO] [1706867412.482707]: ARM moving
[INFO] [1706867413.484747]: ARM moving
[INFO] [1706867414.486791]: ARM moving
x,y,radius 710 594 202
x,y,radius 714 598 206
x,y,radius 722 596 204
x,y,radius 740 312 216
x,y,radius 740 326 216
x,y,radius 718 332 222
x,y,radius 706 334 220
x,y,radius 712 346 220
x,y,radius 702 342 224
x,y,radius 722 350 221
x,y,radius 738 432 220
x,y,radius 742 544 221
x,y,radius 742 554 221
x,y,radius 720 548 208
x,y,radius 708 536 194
x,y,radius 692 524 177
x,y,radius 702 530 186
x,y,radius 712 544 202
x,y,radius 736 562 213
x,y,radius 724 562 203
NEXT MOVE
delta_x: 0.10000000000002274, delta_y: 66.69999999999999, radius: 209.8, distance:340.8007626310772
delta_x_T_GOAL: 0.01570130648023686
T goal: [[   0    0   -1 -450]
 [   0    1    0  -37]
 [   1    0    0  536]
 [   0    0    0    1]]
n 329 0.0024867452083080516
[INFO] [1706867424.712062]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867426.714208]: ARM moving
[INFO] [1706867427.716409]: ARM moving
[INFO] [1706867428.718222]: ARM moving
[INFO] [1706867429.720321]: ARM moving
[INFO] [1706867430.722453]: ARM moving
x,y,radius 692 534 185
x,y,radius 720 542 192
x,y,radius 734 552 214
x,y,radius 922 572 172
x,y,radius 770 640 521
x,y,radius 336 802 136
x,y,radius 680 538 76
x,y,radius 276 718 257
x,y,radius 106 670 265
x,y,radius 952 708 310
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 1402 606 186
x,y,radius 0 0 0
x,y,radius 844 640 203
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 94 484 88
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 292 866 149
x,y,radius 314 552 172
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 60 954 8
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 854 650 218
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 86 336 115
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 70 920 10
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 298 514 166
NEXT MOVE
delta_x: -194.89999999999998, delta_y: -99.89999999999998, radius: 182.15, distance:392.53362613230854
delta_x_T_GOAL: -35.34218297120821
T goal: [[   0    0   -1 -450]
 [   0    1    0  -72]
 [   1    0    0  517]
 [   0    0    0    1]]
n 384 0.0024507767535513455
[INFO] [1706867487.692999]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867489.696776]: ARM moving
[INFO] [1706867490.699064]: ARM moving
[INFO] [1706867491.701746]: ARM moving
[INFO] [1706867492.703357]: ARM moving
[INFO] [1706867493.706153]: ARM moving
x,y,radius 1406 610 213
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 0 0 0
x,y,radius 828 502 185
x,y,radius 854 496 190
x,y,radius 930 508 193
x,y,radius 1010 514 208
x,y,radius 1028 518 222
x,y,radius 868 514 207
x,y,radius 846 504 189
x,y,radius 1024 516 208
x,y,radius 1000 520 223
x,y,radius 982 510 223
x,y,radius 960 488 219
x,y,radius 964 490 216
x,y,radius 1016 514 217
x,y,radius 874 502 196
x,y,radius 984 508 217
x,y,radius 914 506 204
x,y,radius 906 520 173
x,y,radius 956 532 205
x,y,radius 992 520 189
NEXT MOVE
delta_x: 247.10000000000002, delta_y: 25.399999999999977, radius: 204.85, distance:349.03587991213084
delta_x_T_GOAL: 39.90799834445762
T goal: [[   0    0   -1 -450]
 [   0    1    0  -32]
 [   1    0    0  521]
 [   0    0    0    1]]
n 384 0.0024769137533102474
[INFO] [1706867510.133905]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867512.136761]: ARM moving
[INFO] [1706867513.138378]: ARM moving
[INFO] [1706867514.140248]: ARM moving
[INFO] [1706867515.142284]: ARM moving
[INFO] [1706867516.144102]: ARM moving
x,y,radius 910 514 180
x,y,radius 878 500 186
x,y,radius 882 504 179
x,y,radius 704 542 214
x,y,radius 664 542 209
x,y,radius 640 536 202
x,y,radius 640 534 197
x,y,radius 704 534 200
x,y,radius 742 540 213
x,y,radius 668 542 213
x,y,radius 632 534 201
x,y,radius 688 532 198
x,y,radius 746 544 203
x,y,radius 714 542 214
x,y,radius 666 546 209
x,y,radius 630 538 205
x,y,radius 646 536 195
x,y,radius 706 536 195
x,y,radius 746 536 204
x,y,radius 744 546 210
NEXT MOVE
Target goal alligned, transition to APPROACH ROBOT ARM
CURRENT DISTANCE FROM TARGET: 349.03587991213084
n 489 0.0024472498407633212
[INFO] [1706867527.224235]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867529.225930]: ARM moving
[INFO] [1706867530.227882]: ARM moving
x,y,radius 698 542 211
x,y,radius 672 542 200
x,y,radius 706 536 199
x,y,radius 722 552 247
x,y,radius 740 552 248
x,y,radius 738 548 244
x,y,radius 712 552 246
x,y,radius 718 560 252
x,y,radius 696 562 254
x,y,radius 724 570 260
x,y,radius 700 566 259
x,y,radius 730 564 254
x,y,radius 730 556 251
x,y,radius 750 552 246
x,y,radius 724 552 238
x,y,radius 692 550 232
x,y,radius 614 562 250
x,y,radius 788 678 153
x,y,radius 710 564 263
x,y,radius 634 560 240
NEXT MOVE
Target goal alligned, transition to APPROACH ROBOT ARM
CURRENT DISTANCE FROM TARGET: 349.03587991213084
n 498 0.002488295662146615
[INFO] [1706867550.862859]: Sent FollowJointTrajectoryActionGoal message.
[INFO] [1706867552.865039]: ARM moving
[INFO] [1706867553.867160]: ARM moving
x,y,radius 640 574 288
x,y,radius 674 552 247
x,y,radius 626 582 260
x,y,radius 566 616 363
x,y,radius 646 616 362
x,y,radius 634 630 334
x,y,radius 706 602 318
x,y,radius 962 620 302
x,y,radius 674 458 165
x,y,radius 90 420 744
x,y,radius 618 534 262
x,y,radius 838 542 289
x,y,radius 610 502 294
x,y,radius 518 408 320
x,y,radius 718 396 277
x,y,radius 656 364 296
x,y,radius 832 288 355
x,y,radius 926 248 306
x,y,radius 838 392 302
x,y,radius 1060 540 111
NEXT MOVE
delta_x: -28.399999999999977, delta_y: 45.80000000000001, radius: 309.75, distance:230.8313155770783
delta_x_T_GOAL: -3.020459969314728
T goal: [[   0    0   -1 -650]
 [   0    1    0  -35]
 [   1    0    0  525]
 [   0    0    0    1]]
n 447 0.002485183969077075
[INFO] [1706867672.595427]: Sent FollowJointTrajectoryActionGoal message.
^A[INFO] [1706867674.597728]: ARM moving
[INFO] [1706867675.599898]: ARM moving
[INFO] [1706867676.601330]: ARM moving
[INFO] [1706867677.603292]: ARM moving
[INFO] [1706867678.605153]: ARM moving
x,y,radius 904 646 243
x,y,radius 1046 670 350
x,y,radius 1058 314 180
x,y,radius 792 228 185
x,y,radius 680 226 56
x,y,radius 848 88 105
Killed

