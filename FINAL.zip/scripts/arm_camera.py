#!/usr/bin/env python

import rospy
import gxipy as gx
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from detect_balloon import get_balloon_loc
import cv2

class DahengCamera:
    def __init__(self):
        # rospy.init_node('daheng_camera_node', anonymous=True)

        # Initialize the Daheng camera
        self.device_manager = gx.DeviceManager()
        dev_num, dev_info_list = self.device_manager.update_device_list()
        if dev_num == 0:
            rospy.logerr("Number of enumerated devices is 0")
            return

        # Open the first device
        self.cam = self.device_manager.open_device_by_index(1)

        # Check if the camera is a color camera
        if not self.cam.PixelColorFilter.is_implemented():
            rospy.logerr("This script does not support mono cameras.")
            self.cam.close_device()
            return

        # Set camera settings
        self.cam.TriggerMode.set(gx.GxSwitchEntry.OFF)
        self.cam.ExposureTime.set(10000.0)
        self.cam.Gain.set(10.0)

        # Adjust white balance (if supported)
        if self.cam.BalanceWhiteAuto.is_implemented():
            self.cam.BalanceWhiteAuto.set(gx.GxAutoEntry.CONTINUOUS)

        # Get parameters for improving image quality
        self.gamma_lut = gx.Utility.get_gamma_lut(self.cam.GammaParam.get()) if self.cam.GammaParam.is_readable() else None
        self.contrast_lut = gx.Utility.get_contrast_lut(self.cam.ContrastParam.get()) if self.cam.ContrastParam.is_readable() else None
        self.color_correction_param = self.cam.ColorCorrectionParam.get() if self.cam.ColorCorrectionParam.is_readable() else 0

        # Start data acquisition
        self.cam.stream_on()

    def capture_image(self):
        # Get raw image
        raw_image = self.cam.data_stream[-1].get_image()
        if raw_image is None:
            rospy.logwarn("Getting image failed.")
            return None

        # Convert to RGB and impdetection_settingsrove image quality
        rgb_image = raw_image.convert("RGB")
        if rgb_image is not None:
            rgb_image.image_improvement(self.color_correction_param, self.contrast_lut, self.gamma_lut)
            numpy_image = rgb_image.get_numpy_array()
            if numpy_image is not None:
                numpy_image = cv2.cvtColor(numpy_image, cv2.COLOR_RGB2BGR)
            return numpy_image

        return None

    def close_camera(self):
        # Stop data acquisition and close device
        self.cam.stream_off()
        self.cam.close_device()

if __name__ == '__main__':
    try:
        camera = DahengCamera()

        while True:
            hue_lower = cv2.getTrackbarPos("Hue Lower", "Color Range Adjustments")
            saturation_lower = cv2.getTrackbarPos("Saturation Lower", "Color Range Adjustments")
            value_lower = cv2.getTrackbarPos("Value Lower", "Color Range Adjustments")
            hue_upper = cv2.getTrackbarPos("Hue Upper", "Color Range Adjustments")
            saturation_upper = cv2.getTrackbarPos("Saturation Upper", "Color Range Adjustments")
            value_upper = cv2.getTrackbarPos("Value Upper", "Color Range Adjustments")
            minDist = cv2.getTrackbarPos("minDist", "Color Range Adjustments")
            Param1 = cv2.getTrackbarPos("Param1", "Color Range Adjustments")
            Param2 = cv2.getTrackbarPos("Param2", "Color Range Adjustments")

            detection_settings = {
                "hue_lower": hue_lower,
                "saturation_lower": saturation_lower,
                "value_lower": value_lower,
                "hue_upper": hue_upper,
                "saturation_upper": saturation_upper,
                "value_upper": value_upper,
                "minDist": minDist,
                "param1": Param1,
                "param2": Param2,
                "minRadius": 5,
                "maxRadius": 1000
            }
            get_balloon_loc(camera.capture_image(), detection_settings)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break

        camera.close_camera()
    except rospy.ROSInterruptException:
        rospy.logerr("ROS Interrupt Exception")
        camera.close_camera()


