#!/usr/bin/env python

from FSM_controller import StateMachine
from FSM_nodes.initial_detection import initial_detection
from FSM_nodes.approach_target import approach_target
from FSM_nodes.pointing_robot_arm import pointing_robot_arm
from FSM_nodes.approach_robot_arm import approach_robot_arm

from data_handler import DataHandler
from arm_camera import DahengCamera

from actionlib_msgs.msg import GoalStatusArray
from sensor_msgs.msg import Image

import rospy


context = {}

handler = DataHandler()
context["handler"] = handler

rospy.init_node('data_handler', anonymous=True)
context["handler"].subscribe_to_topic('/robot/arm/scaled_pos_traj_controller/fotlllow_joint_trajectory/status', GoalStatusArray)
context["handler"].subscribe_to_topic('/robot/move/status', GoalStatusArray)
context["handler"].subscribe_to_topic('/robot/front_rgbd_camera/color/image_raw', Image)
context["handler"].subscribe_to_topic('/robot/arm/scaled_pos_traj_controller/follow_joint_trajectory/status', GoalStatusArray)


deheng_camera = DahengCamera()
context["daheng_camera"] = deheng_camera

image = context["daheng_camera"].capture_image()
img_width = len(image[0])
img_height = len(image)	
context["dc_x_center"]  = img_width / 2
context["dc_y_center"] = img_height / 2


rospy.sleep(1)


if __name__ == "__main__":
	m = StateMachine()
	m.add_state("INITIAL DETECTION", initial_detection)
	m.add_state("APPROACH TARGET", approach_target)
	m.add_state("POINTING ROBOT ARM", pointing_robot_arm)
	m.add_state("APPROACH ROBOT ARM", approach_robot_arm)
	m.add_state("FINISH", None, end_state=1)
	
	m.set_start("INITIAL DETECTION")
	m.run(context=context)

